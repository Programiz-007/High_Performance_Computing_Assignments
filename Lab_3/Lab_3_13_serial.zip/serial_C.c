#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
#define min(x, y) (((x) < (y)) ? (x) : (y))
#define CLK CLOCK_MONOTONIC

struct timespec diff(struct timespec start, struct timespec end){
    struct timespec temp;
    if((end.tv_nsec-start.tv_nsec)<0){
        temp.tv_sec = end.tv_sec-start.tv_sec-1;
        temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
    }
    else{
        temp.tv_sec = end.tv_sec-start.tv_sec;
        temp.tv_nsec = end.tv_nsec-start.tv_nsec;
    }
    return temp;
}

int main(int argc, char* argv[])
{
    struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;
    clock_gettime(CLK, &start_e2e);

    if(argc < 3){
        printf( "Usage: %s n p \n", argv[0] );
        return -1;
    }

    int N = atoi(argv[1]);    /* Matrix size N x N */
    int P = atoi(argv[2]);    /* Number of processors (not used in serial) */
    char *problem_name = "matrix_multiplication";
    char *approach_name = "serial";

    char outputFileName[50];        
    sprintf(outputFileName,"output/%s_%s_%s_%s_output.txt",problem_name,approach_name,argv[1],argv[2]);
   
    // Variable Declaration
    double **A, **B, **C;
    A = (double **)malloc(N * sizeof(double *));
    B = (double **)malloc(N * sizeof(double *));
    C = (double **)malloc(N * sizeof(double *));
    int i;
    for (i = 0; i < N; i++) {
        A[i] = (double *)malloc(N * sizeof(double));
        B[i] = (double *)malloc(N * sizeof(double));
        C[i] = (double *)malloc(N * sizeof(double));
    }

    // Initialize matrices A and B with random values, C with zeros
    int r,t;
    for (r = 0; r < N; r++) {
        for (t = 0; t < N; t++) {
            A[r][t] = rand() % 10;
            B[r][t] = rand() % 10;
            C[r][t] = 0.0;
        }
    }
   
    clock_gettime(CLK, &start_alg);    /* Start the algo timer */
    /*----------------------Core algorithm starts here----------------------------------------------*/
   
    // Block matrix multiplication (Divide and Conquer Strategy)
    int blockSize = 32; // Adjust block size based on cache size  16 for HPC Cluster
    int i1, j1, k1;
    for (i = 0; i < N; i += blockSize) {
        for (j = 0; j < N; j += blockSize) {
            for (k = 0; k < N; k += blockSize) {
                for (i1 = i; i1 < min(i + blockSize, N); i1++) {
                    for (j1 = j; j1 < min(j + blockSize, N); j1++) {
                        for (k1 = k; k1 < min(k + blockSize, N); k1++) {
                            C[i1][j1] += A[i1][k1] * B[k1][j1];
                        }
                    }
                }
            }
        }
    }
   
    /*----------------------Core algorithm ends here----------------------------------------------*/
   
    clock_gettime(CLK, &end_alg);    /* End the algo timer */
   
    clock_gettime(CLK, &end_e2e);
    e2e = diff(start_e2e, end_e2e);
    alg = diff(start_alg, end_alg);
   
    // Free allocated memory
    int y;
    for (y = 0; y < N; y++) {
        free(A[y]); free(B[y]); free(C[y]);
    }
    free(A); free(B); free(C);
   
    // Print CSV format output
    printf("%s,%s,%d,%d,%d,%ld,%d,%ld\n",
           problem_name, approach_name, N, P,
           e2e.tv_sec, e2e.tv_nsec,
           alg.tv_sec, alg.tv_nsec);
   
    return 0;
}
#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
#define min(x, y) (((x) < (y)) ? (x) : (y))
#define CLK CLOCK_MONOTONIC

struct timespec diff(struct timespec start, struct timespec end){
    struct timespec temp;
    if((end.tv_nsec-start.tv_nsec)<0){
        temp.tv_sec = end.tv_sec-start.tv_sec-1;
        temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
    }
    else{
        temp.tv_sec = end.tv_sec-start.tv_sec;
        temp.tv_nsec = end.tv_nsec-start.tv_nsec;
    }
    return temp;
}

int main(int argc, char* argv[])
{
    struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;
    clock_gettime(CLK, &start_e2e);

    if(argc < 3){
        printf( "Usage: %s n p \n", argv[0] );
        return -1;
    }

    int N = atoi(argv[1]);    /* Matrix size N x N */
    int P = atoi(argv[2]);    /* Number of processors (not used in serial) */
    char *problem_name = "matrix_multiplication";
    char *approach_name = "serial";

    char outputFileName[50];        
    sprintf(outputFileName,"output/%s_%s_%s_%s_output.txt",problem_name,approach_name,argv[1],argv[2]);
   
    // Variable Declaration
    double **A, **B, **C;
    A = (double **)malloc(N * sizeof(double *));
    B = (double **)malloc(N * sizeof(double *));
    C = (double **)malloc(N * sizeof(double *));
    int i;
    for (i = 0; i < N; i++) {
        A[i] = (double *)malloc(N * sizeof(double));
        B[i] = (double *)malloc(N * sizeof(double));
        C[i] = (double *)malloc(N * sizeof(double));
    }

    // Initialize matrices A and B with random values, C with zeros
    int r,t;
    for (r = 0; r < N; r++) {
        for (t = 0; t < N; t++) {
            A[r][t] = rand() % 10;
            B[r][t] = rand() % 10;
            C[r][t] = 0.0;
        }
    }
   
    clock_gettime(CLK, &start_alg);    /* Start the algo timer */
    /*----------------------Core algorithm starts here----------------------------------------------*/
   
    // Block matrix multiplication (Divide and Conquer Strategy)
    int blockSize = 32; // Adjust block size based on cache size
    int i1, j1, k1;
    for (i = 0; i < N; i += blockSize) {
        for (j = 0; j < N; j += blockSize) {
            for (k = 0; k < N; k += blockSize) {
                for (i1 = i; i1 < min(i + blockSize, N); i1++) {
                    for (j1 = j; j1 < min(j + blockSize, N); j1++) {
                        for (k1 = k; k1 < min(k + blockSize, N); k1++) {
                            C[i1][j1] += A[i1][k1] * B[k1][j1];
                        }
                    }
                }
            }
        }
    }
   
    /*----------------------Core algorithm ends here----------------------------------------------*/
   
    clock_gettime(CLK, &end_alg);    /* End the algo timer */
   
    clock_gettime(CLK, &end_e2e);
    e2e = diff(start_e2e, end_e2e);
    alg = diff(start_alg, end_alg);
   
    // Free allocated memory
    int y;
    for (y = 0; y < N; y++) {
        free(A[y]); free(B[y]); free(C[y]);
    }
    free(A); free(B); free(C);
   
    // Print CSV format output
    printf("%s,%s,%d,%d,%d,%ld,%d,%ld\n",
           problem_name, approach_name, N, P,
           e2e.tv_sec, e2e.tv_nsec,
           alg.tv_sec, alg.tv_nsec);
   
    return 0;
}
