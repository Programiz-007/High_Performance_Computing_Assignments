#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
#define min(x, y) (((x) < (y)) ? (x) : (y))
#define CLK CLOCK_MONOTONIC

struct timespec diff(struct timespec start, struct timespec end){
    struct timespec temp;
    if((end.tv_nsec-start.tv_nsec)<0){
        temp.tv_sec = end.tv_sec-start.tv_sec-1;
        temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
    }
    else{
        temp.tv_sec = end.tv_sec-start.tv_sec;
        temp.tv_nsec = end.tv_nsec-start.tv_nsec;
    }
    return temp;
}

int main(int argc, char* argv[])
{
    struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;
    clock_gettime(CLK, &start_e2e);

    if(argc < 3){
        printf( "Usage: %s n p \n", argv[0] );
        return -1;
    }

    int N = atoi(argv[1]);    /* Matrix size N x N */
    int P = atoi(argv[2]);    /* Number of processors (not used in serial) */
    char *problem_name = "matrix_multiplication";
    char *approach_name = "serial";

    char outputFileName[50];        
    sprintf(outputFileName,"output/%s_%s_%s_%s_output.txt",problem_name,approach_name,argv[1],argv[2]);
   
    // Variable Declaration 
    double **A, **B, **C;
    A = (double **)malloc(N * sizeof(double *));
    B = (double **)malloc(N * sizeof(double *));
    C = (double **)malloc(N * sizeof(double *));
    int i;
    for (i = 0; i < N; i++) {
        A[i] = (double *)malloc(N * sizeof(double));
        B[i] = (double *)malloc(N * sizeof(double));
        C[i] = (double *)malloc(N * sizeof(double));
    }

    // Initialize matrices A and B with random values, C with zeros
    int r,t;
    for (r = 0; r < N; r++) {
        for ( t = 0; t < N; t++) {
            A[r][t] = rand() % 10;
            B[r][t] = rand() % 10;
            C[r][t] = 0.0;
        }
    }
   
    clock_gettime(CLK, &start_alg);    /* Start the algo timer */
    /*----------------------Core algorithm starts here----------------------------------------------*/
    
    // Six possible loop orderings for matrix multiplication
    // Uncomment the required one before execution
    
    // Order: i-j-k
    int a,b,c;
    // for (a = 0; a < N; a++) {
    //     for ( b = 0; b < N; b++) {
    //         for ( c = 0; c < N; c++) {
    //             C[a][b] += A[a][c] * B[c][b];
    //         }
    //     }
    // }
    
    /* Alternative orders (uncomment to use) */
    
    // Order: i-k-j
    // for (int i = 0; i < N; i++) {
    //     for (int k = 0; k < N; k++) {
    //         for (int j = 0; j < N; j++) {
    //             C[i][j] += A[i][k] * B[k][j];
    //         }
    //     }
    // }
    
    // Order: j-i-k
    // for (int j = 0; j < N; j++) {
    //     for (int i = 0; i < N; i++) {
    //         for (int k = 0; k < N; k++) {
    //             C[i][j] += A[i][k] * B[k][j];
    //         }
    //     }
    // }
    
    // Order: j-k-i
    // for (int j = 0; j < N; j++) {
    //     for (int k = 0; k < N; k++) {
    //         for (int i = 0; i < N; i++) {
    //             C[i][j] += A[i][k] * B[k][j];
    //         }
    //     }
    // }
    
    // Order: k-i-j
    for ( c = 0; c < N; c++) {
        for ( a = 0; a < N; a++) {
            for ( b = 0; b < N; b++) {
                C[a][b] += A[a][c] * B[c][b];
            }
        }
    }
    
    // Order: k-j-i
    // for (int k = 0; k < N; k++) {
    //     for (int j = 0; j < N; j++) {
    //         for (int i = 0; i < N; i++) {
    //             C[i][j] += A[i][k] * B[k][j];
    //         }
    //     }
    // }
    
    /*----------------------Core algorithm ends here----------------------------------------------*/
   
    clock_gettime(CLK, &end_alg);    /* End the algo timer */
   
    clock_gettime(CLK, &end_e2e);
    e2e = diff(start_e2e, end_e2e);
    alg = diff(start_alg, end_alg);
   
    // Free allocated memory
    int y;
    for (y = 0; y < N; y++) {
        free(A[y]); free(B[y]); free(C[y]);
    }
    free(A); free(B); free(C);
   
    // Print CSV format output
    printf("%s,%s,%d,%d,%d,%ld,%d,%ld\n",
           problem_name, approach_name, N, P,
           e2e.tv_sec, e2e.tv_nsec,
           alg.tv_sec, alg.tv_nsec);
   
    return 0;
}