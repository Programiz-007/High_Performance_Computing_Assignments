#include<stdio.h>
#include<math.h>
#include<omp.h>
#include<time.h>
#include<string.h>
#include<stdlib.h>
#define min(x, y) (((x) < (y)) ? (x) : (y))
#define CLK CLOCK_MONOTONIC

// Function to integrate: 4/(1 + x^2)
double f(double x) {
    return 4.0 / (1.0 + x * x);
}

struct timespec diff(struct timespec start, struct timespec end){
    struct timespec temp;
    if((end.tv_nsec-start.tv_nsec)<0){
        temp.tv_sec = end.tv_sec-start.tv_sec-1;
        temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
    }
    else{
        temp.tv_sec = end.tv_sec-start.tv_sec;
        temp.tv_nsec = end.tv_nsec-start.tv_nsec;
    }
    return temp;
}

int main(int argc, char* argv[])
{
    struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;
    clock_gettime(CLK, &start_e2e);

    if(argc < 3){
        printf( "Usage: %s n p \n", argv[0] );
        return -1;
    }

    int N = atoi(argv[1]);    /* N intervals for integration */
    int P = atoi(argv[2]);    /* number of processors*/
    char *problem_name = "trapezoidal_pi";
    char *approach_name = "serial";

    char outputFileName[50];        
    sprintf(outputFileName,"output/%s_%s_%s_%s_output.txt",problem_name,approach_name,argv[1],argv[2]);
   
    // Variables for π calculation
    double h, x, sum = 0.0;
    double pi_result;
    int i = 1;
    long long flops = 0;  // Count floating point operations
   
    clock_gettime(CLK, &start_alg);    /* Start the algo timer */
    /*----------------------Core algorithm starts here----------------------------------------------*/
   
    // Calculate step size
    h = 1.0 / N;
   
    // Initial and final points contribute half
    sum = 0.5 * (f(0.0) + f(1.0));
    flops += 2;  // Two function evaluations
   
    // Main integration loop
    for(i=1; i < N; i++) {
        x = i * h;
        sum += f(x);
        flops += 7;  // 1 mult for i*h, 3 add, 1 div, 2 mult in f(x)
    }
   
    // Final multiplication
    pi_result = h * sum;
    flops += 1;
   
    /*----------------------Core algorithm finished--------------------------------------------------*/
    clock_gettime(CLK, &end_alg);    /* End the algo timer */
   
    clock_gettime(CLK, &end_e2e);
    e2e = diff(start_e2e, end_e2e);
    alg = diff(start_alg, end_alg);
   
    // Calculate error
    double error = fabs(pi_result - M_PI);
   
    // Open output file for results
    FILE *outputFile = fopen(outputFileName, "w");
    if (outputFile != NULL) {
        fprintf(outputFile, "Number of intervals (N): %d\n", N);
        fprintf(outputFile, "Calculated π: %.10f\n", pi_result);
        fprintf(outputFile, "Actual π: %.10f\n", M_PI);
        fprintf(outputFile, "Absolute Error: %.10e\n", error);
        fprintf(outputFile, "Total FLOPs: %lld\n", flops);
        fprintf(outputFile, "MFLOPS/sec: %.2f\n", (flops / 1e6) / (alg.tv_sec + alg.tv_nsec / 1e9));
        fclose(outputFile);
    }
   
    // Print CSV format output
    printf("%s,%s,%d,%d,%d,%ld,%d,%ld\n",
           problem_name, approach_name, N, P,
           e2e.tv_sec, e2e.tv_nsec,
           alg.tv_sec, alg.tv_nsec);
   
    return 0;
}
